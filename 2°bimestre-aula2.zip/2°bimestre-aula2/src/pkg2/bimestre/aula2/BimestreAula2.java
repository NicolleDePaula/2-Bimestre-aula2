/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2.bimestre.aula2;

import javax.swing.JOptionPane;

/**
 *
 * @author nicolle.pabreu
 */
public class BimestreAula2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String nome = JOptionPane.showInputDialog(null, "Informe seu nome");
        //JOptionPane.showMessageDialog(null, "Olá" + nome);
        double numero1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite um número:"));
        double numero2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite outro valor"));
        double multiplicacao = numero1 * numero2;
        JOptionPane.showMessageDialog(null, "resultado: " + multiplicacao);
    }
    
}
