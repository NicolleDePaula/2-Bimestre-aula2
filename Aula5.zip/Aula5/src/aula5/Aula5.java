/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula5;

/**
 *
 * @author nicolle.pabreu
 */
public class Aula5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //for(int contador = 1;contador <=20;contador++){
        //System.out.println("Nicolle");
        int tabuada = 8;
        for(int contador = 1; contador <=10;contador++){
            System.out.println("8 *"+ contador  +"="+ tabuada * contador);
    }
    }
}
